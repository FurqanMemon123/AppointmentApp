// ignore_for_file: prefer_const_constructors, file_names

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smit_test/Admin/AdminDashboard.dart';
import 'package:smit_test/Doctor/DoctorDashboard.dart';
import 'package:smit_test/Login/LoginPage.dart';
import 'package:smit_test/Users/Homepage.dart'; // Add the DoctorDashboard import

class Wrapper extends StatefulWidget {
  const Wrapper({super.key});

  @override
  State<Wrapper> createState() => _WrapperState();
}

class _WrapperState extends State<Wrapper> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _loadingIndicator(); // Show loading while waiting for auth state
          }

          if (snapshot.hasData) {
            User? user = snapshot.data;
            return FutureBuilder<void>(
              future: _checkUser(user!),
              builder: (context, futureSnapshot) {
                if (futureSnapshot.connectionState == ConnectionState.waiting) {
                  return _loadingIndicator(); // Show loading while checking user type
                } else {
                  return Container(); // Placeholder while the user type is being checked
                }
              },
            );
          } else {
            return LoginPage(); // User is not logged in
          }
        },
      ),
    );
  }

  Widget _loadingIndicator() {
    return Center(child: CircularProgressIndicator());
  }

  Future<void> _setPrefs(Map<String, dynamic> data) async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool("Login", true);
      await prefs.setString("userType", data["Type"]);
    } catch (e) {
      print("Error setting preferences: $e");
    }
  }

  Future<void> _checkUser(User user) async {
    try {
      // Check if user exists in the "Admin" collection
      DocumentSnapshot adminDoc =
          await FirebaseFirestore.instance.collection("Admin").doc(user.uid).get();
      if (adminDoc.exists) {
        await _handleAdminUser(adminDoc.data() as Map<String, dynamic>);
        return;
      }

      // Check if user exists in the "Doctors" collection
      DocumentSnapshot doctorDoc =
          await FirebaseFirestore.instance.collection("Doctors").doc(user.uid).get();
      if (doctorDoc.exists) {
        await _handleDoctorUser(doctorDoc.data() as Map<String, dynamic>);
        return;
      }

      // Check if user exists in the "Users" collection
      await _handleRegularUser(user);
    } catch (e) {
      print("Error checking user: $e");
      Get.snackbar("Error", "An error occurred while checking user.", colorText: Colors.white);
    }
  }

  Future<void> _handleAdminUser(Map<String, dynamic> adminData) async {
    await _setPrefs(adminData); // Save admin preferences
    Get.offAll(AdminDashboard());
  }

  Future<void> _handleDoctorUser(Map<String, dynamic> doctorData) async {
    await _setPrefs(doctorData); // Save doctor preferences
    Get.offAll(DoctorDashboard()); // Navigate to DoctorDashboard
  }

  Future<void> _handleRegularUser(User user) async {
    DocumentSnapshot userDoc =
        await FirebaseFirestore.instance.collection("Users").doc(user.uid).get();
    if (userDoc.exists) {
      Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;
      bool isBlocked = userData['isBlocked'] ?? false;

      if (isBlocked) {
        await _handleBlockedUser();
      } else {
        await _setPrefs(userData); // Save user preferences
        Get.offAll(UserDashboard());
      }
    } else {
      Get.snackbar("Error", "User does not exist in any collection.", colorText: Colors.white);
      await FirebaseAuth.instance.signOut(); // Log out the user
    }
  }

  Future<void> _handleBlockedUser() async {
    await FirebaseAuth.instance.signOut(); // Log out the blocked user
    Get.offAll(LoginPage());
    Get.snackbar("Access Denied", "Your account is blocked.", colorText: Colors.white);
  }
}
