import 'package:anim_search_bar/anim_search_bar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:smit_test/Admin/AdminDrawerData.dart';

class DoctorsList extends StatefulWidget {
  const DoctorsList({super.key});

  @override
  State<DoctorsList> createState() => _DoctorsListState();
}

class _DoctorsListState extends State<DoctorsList> {
  TextEditingController _search = TextEditingController();

  final CollectionReference usersCollection =
      FirebaseFirestore.instance.collection('Doctors');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Row(
            children: [
              AnimSearchBar(
                width: MediaQuery.of(context).size.width * 0.99,
                textController: _search,
                onSuffixTap: () {
                  setState(() {
                    _search.clear();
                  });
                },
                rtl: false,
                onSubmitted: (String value) {
                  debugPrint("onSubmitted value: " + value);
                },
              )
            ],
          ),
        ],
        title: Text('Doctors List'),
      ),
      drawer: Drawer(
        child: Drawerdata(),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: usersCollection.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No doctors found.'));
          }

          final doctors = snapshot.data!.docs;
          return ListView.builder(
            itemCount: doctors.length,
            itemBuilder: (context, index) {
              final doctorDoc = doctors[index];
              final userId = doctorDoc.id;

              // Fetch user data (doctorName and email) from the UID document
              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('Doctors') // Change this to 'Users' collection
                    .doc(userId) // Use user UID from the 'Doctors' collection
                    .get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (userSnapshot.hasError) {
                    return Center(child: Text('Error: ${userSnapshot.error}'));
                  }

                  if (userSnapshot.hasData && userSnapshot.data != null) {
                    final userData = userSnapshot.data!.data() as Map<String, dynamic>?;

                    // If the document data is null, return an empty widget
                    if (userData == null) {
                      return SizedBox();
                    }

                    // Get doctorName and email from the user document
                    final doctorName = userData['doctorName'] ?? 'No name available';
                    final email = userData['email'] ?? 'No email available';

                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        child: ListTile(
                          title: Text(doctorName),
                          subtitle: Text(email),
                        ),
                      ),
                    );
                  } else {
                    return SizedBox();
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}
