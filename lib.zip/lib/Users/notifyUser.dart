// // // ignore_for_file: prefer_const_constructors, file_names

// // import 'package:flutter/material.dart';
// // import 'package:cloud_firestore/cloud_firestore.dart';
// // import 'package:food_app/Users/Udrawerdata.dart';

// // // Notification Model
// // class NotificationModel {
// //   String id;
// //   String message;
// //   DateTime timestamp;

// //   NotificationModel(
// //       {required this.id, required this.message, required this.timestamp});

// //   factory NotificationModel.fromMap(Map<String, dynamic> data, String id) {
// //     return NotificationModel(
// //       id: id,
// //       message: data['message'] ?? '',
// //       timestamp: (data['timestamp'] as Timestamp).toDate(),
// //     );
// //   }
// // }

// // // Notification Page
// // class OrderStatus extends StatelessWidget {
// //   final String userId; // Add userId as a parameter
// //   OrderStatus({required this.userId});

// //   Future<void> deleteNotification(
// //       String notificationId, BuildContext context) async {
// //     final CollectionReference notificationsCollection = FirebaseFirestore
// //         .instance
// //         .collection('Users')
// //         .doc(userId)
// //         .collection('Notifications');
// //     await notificationsCollection.doc(notificationId).delete();

// //     // Show Snackbar after deletion
// //     ScaffoldMessenger.of(context).showSnackBar(
// //       SnackBar(
// //         content: Text('Notification has been deleted.'),
// //         duration: Duration(seconds: 2),
// //         backgroundColor: Colors.red,
// //       ),
// //     );
// //   }

// //   Future<void> deleteAllNotifications(BuildContext context) async {
// //     final CollectionReference notificationsCollection = FirebaseFirestore
// //         .instance
// //         .collection('Users')
// //         .doc(userId)
// //         .collection('Notifications');

// //     // Get all notifications
// //     final querySnapshot = await notificationsCollection.get();

// //     // Delete all notifications
// //     for (var doc in querySnapshot.docs) {
// //       await notificationsCollection.doc(doc.id).delete();
// //     }

// //     // Show Snackbar after deleting all notifications
// //     ScaffoldMessenger.of(context).showSnackBar(
// //       SnackBar(
// //         content: Text('All notifications have been deleted.'),
// //         duration: Duration(seconds: 2),
// //         backgroundColor: Colors.red,
// //       ),
// //     );
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     final CollectionReference notificationsCollection = FirebaseFirestore
// //         .instance
// //         .collection('Users')
// //         .doc(userId)
// //         .collection('Notifications');

// //     return Scaffold(
// //       // backgroundColor: Colors.black,
// //       appBar: AppBar(
// //         // backgroundColor: Colors.black,
// //         title: Text('Status',
// //         //  style: TextStyle(color: Colors.white)
// //          ),
// //         // iconTheme: IconThemeData(color: Colors.white),
// //         actions: [
// //           StreamBuilder<QuerySnapshot>(
// //             stream: notificationsCollection
// //                 .orderBy('timestamp', descending: true)
// //                 .snapshots(),
// //             builder: (context, snapshot) {
// //               if (!snapshot.hasData) return Container(); // Loading state

// //               // Check the number of notifications
// //               final notificationCount = snapshot.data!.docs.length;

// //               // Show the button only if there are notifications
// //               if (notificationCount > 0) {
// //                 return TextButton(
// //                   onPressed: () async {
// //                     // Confirm before deleting all notifications
// //                     bool? confirm = await showDialog(
// //                       context: context,
// //                       builder: (context) => AlertDialog(
// //                         title: Text('Delete All Notifications'),
// //                         content: Text('Are you sure you want to delete all notifications?'),
// //                         actions: [
// //                           TextButton(
// //                             onPressed: () => Navigator.of(context).pop(false),
// //                             child: Text('Cancel'),
// //                           ),
// //                           TextButton(
// //                             onPressed: () => Navigator.of(context).pop(true),
// //                             child: Text('Delete All', style: TextStyle(color: Colors.red)),
// //                           ),
// //                         ],
// //                       ),
// //                     );

// //                     if (confirm == true) {
// //                       await deleteAllNotifications(context);
// //                     }
// //                   },
// //                   child: Text('Delete All', style: TextStyle(color: Colors.red)),
// //                 );
// //               } else {
// //                 return Container(); // No button if there are no notifications
// //               }
// //             },
// //           ),
// //         ],
// //       ),
// //       drawer: Drawer(child: UDrawerdata()),
// //       body: StreamBuilder<QuerySnapshot>(
// //         stream: notificationsCollection
// //             .orderBy('timestamp', descending: true)
// //             .snapshots(),
// //         builder: (context, snapshot) {
// //           if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

// //           // Render the body content based on notifications
// //           if (snapshot.data!.docs.isEmpty) {
// //             return Center(
// //               child: Text('No notifications.',
// //               //  style: TextStyle(color: Colors.white)
// //                ),
// //             );
// //           }

// //           List<NotificationModel> notifications = snapshot.data!.docs
// //               .map((doc) => NotificationModel.fromMap(
// //                   doc.data() as Map<String, dynamic>, doc.id))
// //               .toList();

// //           return ListView.builder(
// //             itemCount: notifications.length,
// //             itemBuilder: (context, index) {
// //               NotificationModel notification = notifications[index];
// //               return Column(
// //                 children: [
// //                   ListTile(
// //                     title: Text(notification.message, 
// //                     // style: TextStyle(color: Colors.white)
// //                     ),
// //                     subtitle: Text(notification.timestamp.toLocal().toString(),
// //                     //  style: TextStyle(color: Colors.white)
// //                      ),
// //                     trailing: IconButton(
// //                       icon: Icon(Icons.delete, color: Colors.red),
// //                       onPressed: () async {
// //                         // Confirm before deleting
// //                         bool? confirm = await showDialog(
// //                           context: context,
// //                           builder: (context) => AlertDialog(
// //                             title: Text('Delete Notification'),
// //                             content: Text('Are you sure you want to delete this notification?'),
// //                             actions: [
// //                               TextButton(
// //                                 onPressed: () => Navigator.of(context).pop(false),
// //                                 child: Text('Cancel'),
// //                               ),
// //                               TextButton(
// //                                 onPressed: () => Navigator.of(context).pop(true),
// //                                 child: Text('Delete'),
// //                               ),
// //                             ],
// //                           ),
// //                         );

// //                         if (confirm == true) {
// //                           await deleteNotification(notification.id, context);
// //                         }
// //                       },
// //                     ),
// //                   ),
// //                   Divider(color: Colors.white10),
// //                 ],
// //               );
// //             },
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }


// // ignore_for_file: prefer_const_constructors

// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:food_app/Users/Udrawerdata.dart';

// class NotificationModel {
//   String id;
//   String message;
//   DateTime timestamp;

//   NotificationModel({required this.id, required this.message, required this.timestamp});

//   factory NotificationModel.fromMap(Map<String, dynamic> data, String id) {
//     return NotificationModel(
//       id: id,
//       message: data['message'] ?? '',
//       timestamp: (data['timestamp'] as Timestamp).toDate(),
//     );
//   }
// }

// class OrderStatus extends StatelessWidget {
//   final String userId; // Add userId as a parameter
//   OrderStatus({required this.userId});

//   Future<void> deleteNotification(String notificationId, BuildContext context) async {
//     final CollectionReference notificationsCollection = FirebaseFirestore.instance
//         .collection('Users')
//         .doc(userId)
//         .collection('Notifications');
//     await notificationsCollection.doc(notificationId).delete();

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('Notification has been deleted.'),
//         duration: Duration(seconds: 2),
//         backgroundColor: Colors.red,
//       ),
//     );
//   }

//   Future<void> deleteAllNotifications(BuildContext context) async {
//     final CollectionReference notificationsCollection = FirebaseFirestore.instance
//         .collection('Users')
//         .doc(userId)
//         .collection('Notifications');

//     final querySnapshot = await notificationsCollection.get();

//     for (var doc in querySnapshot.docs) {
//       await notificationsCollection.doc(doc.id).delete();
//     }

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('All notifications have been deleted.'),
//         duration: Duration(seconds: 2),
//         backgroundColor: Colors.red,
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     final CollectionReference notificationsCollection = FirebaseFirestore.instance
//         .collection('Users')
//         .doc(userId)
//         .collection('Notifications');

//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Status'),
//         actions: [
//           StreamBuilder<QuerySnapshot>(
//             stream: notificationsCollection
//                 .orderBy('timestamp', descending: true)
//                 .snapshots(),
//             builder: (context, snapshot) {
//               if (!snapshot.hasData) return Container();

//               final notificationCount = snapshot.data!.docs.length;

//               if (notificationCount > 0) {
//                 return TextButton(
//                   onPressed: () async {
//                     bool? confirm = await showDialog(
//                       context: context,
//                       builder: (context) => AlertDialog(
//                         title: Text('Delete All Notifications'),
//                         content: Text('Are you sure you want to delete all notifications?'),
//                         actions: [
//                           TextButton(
//                             onPressed: () => Navigator.of(context).pop(false),
//                             child: Text('Cancel'),
//                           ),
//                           TextButton(
//                             onPressed: () => Navigator.of(context).pop(true),
//                             child: Text('Delete All', style: TextStyle(color: Colors.red)),
//                           ),
//                         ],
//                       ),
//                     );

//                     if (confirm == true) {
//                       await deleteAllNotifications(context);
//                     }
//                   },
//                   child: Text('Delete All', style: TextStyle(color: Colors.red)),
//                 );
//               } else {
//                 return Container();
//               }
//             },
//           ),
//         ],
//       ),
//       drawer: Drawer(child: UDrawerdata()),
//       body: StreamBuilder<QuerySnapshot>(
//         stream: notificationsCollection
//             .orderBy('timestamp', descending: true)
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

//           if (snapshot.data!.docs.isEmpty) {
//             return Center(
//               child: Text('No notifications.'),
//             );
//           }

//           List<NotificationModel> notifications = snapshot.data!.docs
//               .map((doc) => NotificationModel.fromMap(
//                   doc.data() as Map<String, dynamic>, doc.id))
//               .toList();

//           return ListView.builder(
//             itemCount: notifications.length,
//             itemBuilder: (context, index) {
//               NotificationModel notification = notifications[index];
//               return Column(
//                 children: [
//                   ListTile(
//                     title: Text(notification.message),
//                     subtitle: Text(notification.timestamp.toLocal().toString()),
//                     trailing: IconButton(
//                       icon: Icon(Icons.delete, color: Colors.red),
//                       onPressed: () async {
//                         bool? confirm = await showDialog(
//                           context: context,
//                           builder: (context) => AlertDialog(
//                             title: Text('Delete Notification'),
//                             content: Text('Are you sure you want to delete this notification?'),
//                             actions: [
//                               TextButton(
//                                 onPressed: () => Navigator.of(context).pop(false),
//                                 child: Text('Cancel'),
//                               ),
//                               TextButton(
//                                 onPressed: () => Navigator.of(context).pop(true),
//                                 child: Text('Delete'),
//                               ),
//                             ],
//                           ),
//                         );
//                         if (confirm == true) {
//                           await deleteNotification(notification.id, context);
//                         }
//                       },
//                     ),
//                   ),
//                   Divider(color: Colors.white10),
//                 ],
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:smit_test/Users/UserDrawerData.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Handle background messages here
  await Firebase.initializeApp();
  print("Handling a background message: ${message.messageId}");
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Order Status Notifications',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: OrderStatus(userId: 'user_id_here'), // Replace with actual user ID
    );
  }
}

class NotificationModel {
  String id;
  String message;
  DateTime timestamp;

  NotificationModel({required this.id, required this.message, required this.timestamp});

  factory NotificationModel.fromMap(Map<String, dynamic> data, String id) {
    return NotificationModel(
      id: id,
      message: data['message'] ?? '',
      timestamp: (data['timestamp'] as Timestamp).toDate(),
    );
  }
}

class OrderStatus extends StatefulWidget {
  final String userId;
  OrderStatus({required this.userId});

  @override
  _OrderStatusState createState() => _OrderStatusState();
}

class _OrderStatusState extends State<OrderStatus> {
  late final FirebaseMessaging _messaging;

  @override
  void initState() {
    super.initState();
    _messaging = FirebaseMessaging.instance;
    _requestPermission();
    _setupNotifications();
  }

  Future<void> _requestPermission() async {
    NotificationSettings settings = await _messaging.requestPermission();
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    } else {
      print('User declined or has not accepted permission');
    }
  }

  void _setupNotifications() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        _showNotificationDialog(message.notification!);
        _saveNotification(message);
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');
      // Handle notification tap logic if needed
    });
  }

  void _showNotificationDialog(RemoteNotification notification) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(notification.title ?? 'No Title'),
        content: Text(notification.body ?? 'No Body'),
        actions: [
          TextButton(
            child: Text('OK'),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }

  Future<void> _saveNotification(RemoteMessage message) async {
    final notificationsCollection = FirebaseFirestore.instance
        .collection('Users')
        .doc(widget.userId)
        .collection('Notifications');

    await notificationsCollection.add({
      'message': message.notification?.body ?? 'No Body',
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  @override
  Widget build(BuildContext context) {
    final notificationsCollection = FirebaseFirestore.instance
        .collection('Users')
        .doc(widget.userId)
        .collection('Notifications');

    return Scaffold(
      drawer: Drawer(
        child: UDrawerdata(),
      ),
      appBar: AppBar(
        title: Text('Order Status'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: notificationsCollection.orderBy('timestamp', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          if (snapshot.data!.docs.isEmpty) return Center(child: Text('No notifications.'));

          List<NotificationModel> notifications = snapshot.data!.docs
              .map((doc) => NotificationModel.fromMap(doc.data() as Map<String, dynamic>, doc.id))
              .toList();

          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              NotificationModel notification = notifications[index];
              return ListTile(
                title: Text(notification.message),
                subtitle: Text(notification.timestamp.toLocal().toString()),
                trailing: IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () async {
                    await notificationsCollection.doc(notification.id).delete();
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
